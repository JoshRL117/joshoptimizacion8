from .base import funcion
from .objetivo import objetive_function
from .restriccion import restriction_functions
from .univariablef import univariablefunction